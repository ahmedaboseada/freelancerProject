// api/auth.js
const serverless = require('serverless-http');
const app = require('../authServer/index'); // Adjust the path if necessary

module.exports = serverless(app);
