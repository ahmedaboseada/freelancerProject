// api/gateway.js
const serverless = require('serverless-http');
const app = require('../gatewayServer/index'); // Adjust the path if necessary

module.exports = serverless(app);
