
const gatewayServerApp = require('./gatewayServer/index');
const jobServerApp = require('./jobServer/index');